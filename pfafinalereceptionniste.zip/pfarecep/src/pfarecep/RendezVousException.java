package pfarecep;

public class RendezVousException extends Exception {
	private static final long serialVersionUID = 1L;
    public RendezVousException(String message) {
        super(message);
    }
}

