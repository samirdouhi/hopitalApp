package pfarecep;

public class SalleException extends Exception {
	private static final long serialVersionUID = 1L;
    public SalleException(String message) {
        super(message);
    }
}
